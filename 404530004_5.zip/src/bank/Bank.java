package bank;
import java.util.HashMap;
import java.util.ArrayList;
public class Bank {
	HashMap<Integer,BankAccount> BankList = new HashMap<Integer,BankAccount>();
	private ArrayList<BankAccount> accounts;
	public Bank(){
	accounts = new ArrayList<BankAccount>();
	}

	int getaccountNumber(int accountNumber){	
		for(int i=0;i<accounts.size();i++){
			if(accounts.get(i).accountNumber==accountNumber){	
				return i;					
			}
		}
		return -1;
	}
	void addCheckingAccount(int accountNumber, double initialBalance){
		this.accounts.add(new BankAccount(accountNumber,initialBalance));
	}
	void addSavingsAccount(int accountNumber, double initialBalance, double interestRate){
		this.accounts.add(new BankAccount(accountNumber,initialBalance));
	}
	void addInterest(int accountNumber){
		int AN =getaccountNumber(accountNumber);		
		double B=this.accounts.get(AN).getBalance();
		SavingsAccount SA=new SavingsAccount(accountNumber);
		SavingsAccount SV;
		if( AN>=0 ){
			SV=new ArrayList <SavingAccount>SA;
			SV.addInterest(B);
			}
	}
	void deductFees(int accountNumber){
		int AN=getaccountNumber(accountNumber);		
		CheckingAccount CA =new CheckingAccount(accountNumber);
 		CheckingAccount CK;  
		if(AN >= 0 ){									
 			CK=(CheckingAccount)CA;
 			CK.deductFees();				
 			}
	}
	void transfer(int withdrawAcctNum,int depositAcctNum, double amount){
		int W_Num=getaccountNumber(withdrawAcctNum);
		int D_Num=getaccountNumber(depositAcctNum);
		if(W_Num>=0 && D_Num>=0){
			this.accounts.get(W_Num).withdraw(amount);
			this.accounts.get(D_Num).deposit(amount);
		}
	}
	boolean areEqualAccounts(int accountNumber1, int accountNumber2){
		double a=accounts.get(accountNumber2).getBalance();
		if(accounts.get(accountNumber1).equals(a)==true){	
			return true;
		}
		else return false;
	}

double getBalance(int accountNumber){
	BankAccount tempAccount=(BankAccount)BankList.get(accountNumber);
	return tempAccount.getBalance();
}
String getAccountStatus(int accountNumber){
	BankAccount tempAccount=(BankAccount)BankList.get(accountNumber);
	return tempAccount.state;
}
String summarizeAccountTransactions(int accountNumber){
	StringBuffer sb=new StringBuffer();
	BankAccount tempAccount=(BankAccount)BankList.get(accountNumber);
sb.append("Account #"+accountNumber+"transactions:\n\n");
sb.append(tempAccount.getTransactions());
sb.append("End of transactions\n");
return sb.toString();
}
String summarizeAllAccounts(){
	StringBuffer sb =new StringBuffer();
	sb.append("Account\tBalance\t#Transactions\tStatus\n");
	for(BankAccount bank:BankList.values()){
		
		sb.append(bank.accountNumber+"\t");
		sb.append(bank.getBalance()+"\t");
		sb.append(bank.retrieveNumberOfTransactions()+"\t\t");
		sb.append(bank.state+"\n");
		
	}
	sb.append("End of Account Summary\n");
	return sb.toString();
	
}
void suspendAccount(int accountNumber ){
	BankAccount tempAccount=(BankAccount)BankList.get(accountNumber);
	tempAccount.suspend();
	
}
void reOpenAccount(int accountNumber ){
	BankAccount tempAccount=(BankAccount)BankList.get(accountNumber);
	tempAccount.reOpen();
	
}
void closeAccount(int accountNumber ){
	BankAccount tempAccount=(BankAccount)BankList.get(accountNumber);
	tempAccount.close();
	
}
void addCheckingAccount(int accountNumber){
	
	
}
void addSavingsAccount(int accountNumber){
	
	
}
}
