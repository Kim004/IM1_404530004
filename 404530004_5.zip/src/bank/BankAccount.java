package bank;
import java.util.ArrayList;
public class BankAccount {
	String state; 
int accountNumber;
private double balance;
private ArrayList<Double>TransactionList=null;//important
public BankAccount(){
		this(0,0);	
}

public BankAccount(int anAccountNumber){
	this(anAccountNumber,0);
}
public BankAccount(int anAccountNumber,double initialBalance){
	this.state="open";
	this.accountNumber=anAccountNumber;
	this.balance=initialBalance;
	this.TransactionList=new ArrayList<Double>();
	
	
}//goal
boolean isOpen(){
	if(this.state.equals("open"))
		return true;
	else{
		return false;
	}
} 
boolean isSuspended(){
	if(this.state.equals("suspended"))
		return true;
	else{
		return false;
	}
} 
boolean isClosed(){
	if(this.state.equals("closed"))
		return true;
	else{
		return false;
	}
} 


void reOpen(){
	this.state="open";
}
void suspend(){
	this.state="suspended";
}
void close(){
	this.state="closed";
}
void deposit(double amount)throws Exception{
	if(!this.isOpen()&&amount>0){
		throw new Exception("transcation:"+this.accountNumber+"deposit occur");
		
		
		}
	else{
		this.balance=this.balance+amount;//����[��l�B
		this.TransactionList.add(amount);}
	}
	void withdraw(double amount){
		if(!isOpen()&&amount>0&&this.balance<=amount){
			System.out.println("���ŦX�W�w");
			
			}
		else{
			this.balance=this.balance-amount;//����[��l�B
			this.TransactionList.add(0-amount);
		} 
}
	void addTransaction(double amount) {
		this.TransactionList.add(amount);
	}
	String getTransactions(){
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<this.TransactionList.size();i++){
			sb.append((i+1)+":"+this.TransactionList.get(i)+"\n");
			}
return sb.toString();		
	}
	double getBalance(){
		return this.balance;
		}
	int retrieveNumberOfTransactions(){
		return this.TransactionList.size();
		
	}
	int getaccountNumber(){
		return this.accountNumber;
	}
	String getStatus(){
		if(isOpen()){
			return "open";
		}
		else if(isSuspended()){
			return "suspended"; 
		}
		else	return "closed";
	}
	public boolean equals(double a){
		if(Math.abs(this.balance-a) <= 0.1){
			return true;
		}
		else return false;
	}
}
