package bank;

public class SavingsAccount extends BankAccount {
double interestRate;
	

public SavingsAccount(double rate){
interestRate = rate;
}
//Adds the earned interest to the account balance.
public void addInterest() throws Exception{
double interest = getBalance() *interestRate / 100;
deposit(interest);
}
}


