package yourStudentID_2;

public class EasterTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Easter easter=new Easter();
		System.out.println(easter.calculateEaster(2001));
        System.out.println(easter.calculateEaster(2012));
        
	}

}
